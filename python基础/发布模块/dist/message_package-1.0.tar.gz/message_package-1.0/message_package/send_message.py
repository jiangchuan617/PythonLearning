def seed(text):
    print('正在发送 %s ...' % text)